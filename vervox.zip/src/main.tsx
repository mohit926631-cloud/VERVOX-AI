import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { ClerkAuthProvider } from './components/Auth/ClerkAuthProvider.tsx';
import { GlobalErrorBoundary } from './components/Common/GlobalErrorBoundary.tsx';
import App from './App.tsx';
import './index.css';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <GlobalErrorBoundary>
      <ClerkAuthProvider>
        <App />
      </ClerkAuthProvider>
    </GlobalErrorBoundary>
  </StrictMode>,
);


