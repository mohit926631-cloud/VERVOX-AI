import { ErrorBoundary as ReactErrorBoundary, FallbackProps } from 'react-error-boundary';
import React, { ReactNode } from 'react';

function ErrorFallback({ resetErrorBoundary }: FallbackProps) {
  return (
    <div className="min-h-screen bg-[#0b0f19] text-white flex flex-col items-center justify-center p-6 text-center">
      <div className="max-w-md w-full bg-slate-900/90 border border-slate-800 rounded-3xl p-8 shadow-2xl space-y-6">
        <div className="w-14 h-14 rounded-2xl bg-indigo-600/20 text-indigo-400 flex items-center justify-center text-2xl mx-auto">
          ⚡
        </div>
        <div>
          <h1 className="text-2xl font-bold text-white mb-2">VERVOX AI Workspace</h1>
          <p className="text-sm text-slate-400">
            The application encountered a temporary initialization error and recovered safely.
          </p>
        </div>
        <button
          onClick={() => {
            localStorage.removeItem('clerk_publishable_key');
            resetErrorBoundary();
            window.location.reload();
          }}
          className="w-full py-3 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-bold text-sm shadow-lg shadow-indigo-600/30 transition-all cursor-pointer"
        >
          Reload Application
        </button>
      </div>
    </div>
  );
}

export const GlobalErrorBoundary: React.FC<{ children: ReactNode }> = ({ children }) => {
  return (
    <ReactErrorBoundary FallbackComponent={ErrorFallback}>
      {children}
    </ReactErrorBoundary>
  );
};
