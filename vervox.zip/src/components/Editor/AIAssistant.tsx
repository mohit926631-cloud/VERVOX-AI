import React, { useState, useRef, useEffect } from 'react';
import { AIChatMessage, ProjectFiles, ChatAttachment } from '../../types';
import {
  Sparkles,
  Send,
  Wand2,
  RefreshCw,
  Undo2,
  CheckCircle2,
  Loader2,
  Image as ImageIcon,
  Paperclip,
  X,
  FileText,
  FileCode,
  CornerDownLeft,
} from 'lucide-react';

interface Props {
  messages: AIChatMessage[];
  loading: boolean;
  onSendPrompt: (prompt: string, attachments?: ChatAttachment[]) => void;
  onRegenerate: () => void;
  onUndo: () => void;
  onAddProjectFile?: (filename: string, content: string) => void;
}

export const AIAssistant: React.FC<Props> = ({
  messages,
  loading,
  onSendPrompt,
  onRegenerate,
  onUndo,
  onAddProjectFile,
}) => {
  const [inputPrompt, setInputPrompt] = useState('');
  const [attachments, setAttachments] = useState<ChatAttachment[]>([]);
  const [isUploading, setIsUploading] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);
  const chatBottomRef = useRef<HTMLDivElement>(null);

  const samplePresets = [
    'Add a modern photo gallery grid',
    'Make the navigation bar sticky on mobile',
    'Add a dark / light theme toggle',
    'Add an interactive pricing calculator',
    'Improve responsive typography for mobile phones',
  ];

  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setIsUploading(true);
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const reader = new FileReader();
      reader.onload = (uploadEvent) => {
        const result = uploadEvent.target?.result as string;
        setAttachments((prev) => [
          ...prev,
          {
            name: file.name,
            type: 'image',
            dataUrl: result,
            size: file.size,
          },
        ]);
        setIsUploading(false);
      };
      reader.readAsDataURL(file);
    }
    if (imageInputRef.current) imageInputRef.current.value = '';
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setIsUploading(true);
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const text = await file.text();
      setAttachments((prev) => [
        ...prev,
        {
          name: file.name,
          type: 'file',
          textContent: text,
          size: file.size,
        },
      ]);
      // Optionally auto-add to project files if code file
      if (onAddProjectFile && (file.name.endsWith('.html') || file.name.endsWith('.css') || file.name.endsWith('.js') || file.name.endsWith('.json') || file.name.endsWith('.md'))) {
        onAddProjectFile(file.name, text);
      }
    }
    setIsUploading(false);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const removeAttachment = (index: number) => {
    setAttachments((prev) => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if ((!inputPrompt.trim() && attachments.length === 0) || loading) return;

    let finalPrompt = inputPrompt.trim();
    if (attachments.length > 0) {
      const filesInfo = attachments
        .map((a) => {
          if (a.type === 'image') return `[Attached Image: ${a.name}]`;
          return `[Attached File: ${a.name} (${a.textContent?.length || 0} characters)]`;
        })
        .join('\n');
      finalPrompt = finalPrompt ? `${finalPrompt}\n\nAttachments:\n${filesInfo}` : `Apply changes using attached files/images:\n${filesInfo}`;
    }

    onSendPrompt(finalPrompt, attachments.length > 0 ? attachments : undefined);
    setInputPrompt('');
    setAttachments([]);
  };

  return (
    <div className="w-full h-full bg-slate-950 flex flex-col justify-between border-l border-slate-800/80 text-xs">
      {/* HEADER */}
      <div className="px-4 py-3 bg-slate-900/60 border-b border-slate-800 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-2 font-bold text-slate-200">
          <div className="w-6 h-6 rounded-lg bg-indigo-600/20 text-indigo-400 flex items-center justify-center">
            <Sparkles className="w-3.5 h-3.5" />
          </div>
          <div className="flex flex-col">
            <span className="text-xs font-bold text-white">AI Studio Chat</span>
            <span className="text-[10px] font-mono text-emerald-400 font-semibold">● Online • Gemini AI</span>
          </div>
        </div>

        <div className="flex items-center gap-1">
          <button
            onClick={onRegenerate}
            disabled={loading}
            className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition-colors cursor-pointer"
            title="Regenerate last response"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={onUndo}
            disabled={loading}
            className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition-colors cursor-pointer"
            title="Undo last AI changes"
          >
            <Undo2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* CHAT MESSAGES CONTAINER */}
      <div className="flex-1 p-4 overflow-y-auto space-y-4 font-sans">
        {messages.length === 0 && (
          <div className="text-center py-8 px-4 text-slate-500 space-y-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-600/10 text-indigo-400 flex items-center justify-center mx-auto">
              <Sparkles className="w-5 h-5" />
            </div>
            <div className="font-semibold text-slate-300 text-xs">How can I help with this website?</div>
            <p className="text-[11px] leading-relaxed text-slate-500 max-w-xs mx-auto">
              Ask me to edit code, adjust layouts, upload photos/assets, or change color themes.
            </p>
          </div>
        )}

        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`}
          >
            <div className="flex items-center gap-1.5 text-[10px] text-slate-500 mb-1 px-1">
              {msg.role === 'user' ? 'You' : 'VERVOX AI'} • {msg.timestamp}
            </div>

            <div
              className={`p-3.5 rounded-2xl max-w-[92%] sm:max-w-[85%] text-xs leading-relaxed ${
                msg.role === 'user'
                  ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-br-none shadow-md shadow-indigo-600/20'
                  : 'bg-slate-900 text-slate-200 border border-slate-800 rounded-bl-none shadow-sm'
              }`}
            >
              {/* ATTACHMENTS PREVIEW IN MESSAGE */}
              {msg.attachments && msg.attachments.length > 0 && (
                <div className="mb-2.5 flex flex-wrap gap-2">
                  {msg.attachments.map((att, attIdx) => (
                    <div
                      key={attIdx}
                      className="rounded-xl overflow-hidden border border-white/20 bg-black/20 text-[10px]"
                    >
                      {att.type === 'image' && att.dataUrl ? (
                        <img
                          src={att.dataUrl}
                          alt={att.name}
                          className="w-24 h-20 object-cover rounded-lg"
                        />
                      ) : (
                        <div className="p-2 flex items-center gap-1.5 font-mono text-slate-200">
                          <FileCode className="w-3.5 h-3.5 text-indigo-300" />
                          <span className="truncate max-w-[120px]">{att.name}</span>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}

              <div className="whitespace-pre-wrap">{msg.content}</div>

              {msg.role === 'assistant' && msg.fileChangesSummary && (
                <div className="mt-2.5 pt-2 border-t border-slate-800 text-[10px] text-emerald-400 font-mono flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                  <span>{msg.fileChangesSummary}</span>
                </div>
              )}
            </div>
          </div>
        ))}

        {loading && (
          <div className="flex items-center gap-2.5 p-3.5 rounded-2xl bg-slate-900 border border-slate-800 text-xs text-indigo-300 animate-pulse">
            <Loader2 className="w-4 h-4 animate-spin text-indigo-400" />
            <span>VERVOX AI is generating & updating code...</span>
          </div>
        )}
        <div ref={chatBottomRef} />
      </div>

      {/* QUICK PRESET SUGGESTIONS */}
      <div className="px-3 pt-2 pb-1.5 border-t border-slate-900 bg-slate-950/80">
        <div className="text-[10px] font-semibold text-slate-500 mb-1.5 flex items-center justify-between">
          <span>Suggestions:</span>
          <span className="text-[9px] text-indigo-400">Tap to insert</span>
        </div>
        <div className="flex gap-1.5 overflow-x-auto pb-1 no-scrollbar">
          {samplePresets.map((preset, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => setInputPrompt(preset)}
              disabled={loading}
              className="text-[10px] px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-white transition-colors shrink-0 cursor-pointer"
            >
              + {preset}
            </button>
          ))}
        </div>
      </div>

      {/* ATTACHMENTS BAR BEFORE SENDING */}
      {attachments.length > 0 && (
        <div className="px-3 py-2 bg-slate-900 border-t border-slate-800 flex items-center gap-2 overflow-x-auto">
          {attachments.map((att, idx) => (
            <div
              key={idx}
              className="relative group shrink-0 flex items-center gap-1.5 bg-slate-950 border border-indigo-500/40 rounded-xl p-1.5 pr-2 text-[11px] text-slate-200"
            >
              {att.type === 'image' && att.dataUrl ? (
                <img src={att.dataUrl} alt={att.name} className="w-8 h-8 rounded-lg object-cover" />
              ) : (
                <FileCode className="w-5 h-5 text-indigo-400 p-0.5" />
              )}
              <span className="truncate max-w-[90px] font-mono text-[10px]">{att.name}</span>
              <button
                type="button"
                onClick={() => removeAttachment(idx)}
                className="ml-1 p-0.5 rounded-full hover:bg-rose-500/20 text-slate-400 hover:text-rose-400 transition-colors"
              >
                <X className="w-3 h-3" />
              </button>
            </div>
          ))}
        </div>
      )}

      {/* INPUT FORM WITH PHOTO & FILE UPLOAD */}
      <div className="p-3 bg-slate-950 border-t border-slate-800">
        <form onSubmit={handleSubmit} className="flex flex-col gap-2">
          <div className="relative flex items-center">
            <textarea
              rows={2}
              value={inputPrompt}
              onChange={(e) => setInputPrompt(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSubmit(e);
                }
              }}
              disabled={loading}
              placeholder="Ask AI to change text, colors, layouts, or attach files..."
              className="w-full bg-slate-900 border border-slate-800 rounded-2xl py-2.5 pl-3 pr-24 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 resize-none leading-relaxed"
            />

            {/* ACTION BUTTONS (PHOTO, FILE, SEND) */}
            <div className="absolute right-2 bottom-2.5 flex items-center gap-1">
              <button
                type="button"
                onClick={() => imageInputRef.current?.click()}
                disabled={loading || isUploading}
                className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-300 hover:bg-slate-800 transition-colors cursor-pointer"
                title="Attach photo/screenshot"
              >
                <ImageIcon className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                disabled={loading || isUploading}
                className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-300 hover:bg-slate-800 transition-colors cursor-pointer"
                title="Attach code or document file"
              >
                <Paperclip className="w-4 h-4" />
              </button>

              <button
                type="submit"
                disabled={(!inputPrompt.trim() && attachments.length === 0) || loading}
                className="p-1.5 bg-gradient-to-r from-indigo-600 to-purple-600 rounded-xl text-white hover:from-indigo-500 hover:to-purple-500 disabled:opacity-30 transition-all shadow-md shadow-indigo-600/20 cursor-pointer"
                title="Send instruction to AI"
              >
                <Send className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* HIDDEN FILE INPUTS */}
          <input
            type="file"
            ref={imageInputRef}
            onChange={handlePhotoUpload}
            accept="image/*"
            className="hidden"
            multiple
          />
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileUpload}
            accept=".html,.css,.js,.json,.txt,.md,.svg,.png,.jpg,.jpeg"
            className="hidden"
            multiple
          />

          <div className="flex items-center justify-between text-[10px] text-slate-500 px-1">
            <span>💡 Attach photos/logos or code files directly</span>
            <span className="hidden sm:inline">Press Enter ↵ to send</span>
          </div>
        </form>
      </div>
    </div>
  );
};
