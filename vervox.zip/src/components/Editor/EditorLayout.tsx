import React, { useState } from 'react';
import { Project, AIChatMessage, ViewMode, ChatAttachment } from '../../types';
import { FileExplorer } from './FileExplorer';
import { CodeEditor } from './CodeEditor';
import { LivePreview } from './LivePreview';
import { AIAssistant } from './AIAssistant';
import { Sparkles, ArrowLeft, Download, Save, Eye, Code2, Bot, Layout, RefreshCw, Smartphone, Tablet, Laptop } from 'lucide-react';

interface Props {
  project: Project;
  messages: AIChatMessage[];
  loading: boolean;
  onNavigate: (view: ViewMode) => void;
  onUpdateFiles: (files: Project['files']) => void;
  onSaveProject: () => void;
  onDownloadZip: () => void;
  onSendAIPrompt: (prompt: string, attachments?: ChatAttachment[]) => void;
  onRegenerateAI: () => void;
  onUndoAI: () => void;
  onToast: (type: 'success' | 'error' | 'info', message: string) => void;
}

export const EditorLayout: React.FC<Props> = ({
  project,
  messages,
  loading,
  onNavigate,
  onUpdateFiles,
  onSaveProject,
  onDownloadZip,
  onSendAIPrompt,
  onRegenerateAI,
  onUndoAI,
  onToast,
}) => {
  const [activeFile, setActiveFile] = useState('index.html');
  const [mobileTab, setMobileTab] = useState<'preview' | 'code' | 'ai'>('preview');

  const handleFileContentChange = (filename: string, newContent: string) => {
    const updated = { ...project.files, [filename]: newContent };
    onUpdateFiles(updated);
  };

  const handleAddFile = (filename: string, content?: string) => {
    const updated = {
      ...project.files,
      [filename]: content || `/* ${filename} */\n`,
    };
    onUpdateFiles(updated);
    setActiveFile(filename);
    onToast('success', `File "${filename}" added to project.`);
  };

  const handleDeleteFile = (filename: string) => {
    if (['index.html', 'style.css', 'script.js'].includes(filename)) {
      onToast('error', 'Cannot delete core system files.');
      return;
    }
    const updated = { ...project.files };
    delete updated[filename];
    onUpdateFiles(updated);
    if (activeFile === filename) {
      setActiveFile('index.html');
    }
    onToast('info', `File "${filename}" removed.`);
  };

  return (
    <div className="w-full h-screen bg-slate-950 flex flex-col justify-between overflow-hidden text-slate-100 font-sans">
      {/* TOP APPLICATION BAR */}
      <header className="h-14 px-3 sm:px-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between shrink-0">
        {/* LEFT: BACK TO DASHBOARD & PROJECT TITLE */}
        <div className="flex items-center gap-2 sm:gap-3 min-w-0">
          <button
            onClick={() => onNavigate('dashboard')}
            className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors flex items-center gap-1 text-xs font-semibold shrink-0 cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span className="hidden sm:inline">Dashboard</span>
          </button>

          <div className="h-4 w-px bg-slate-800 hidden sm:block shrink-0" />

          <div className="flex items-center gap-1.5 sm:gap-2 min-w-0 truncate">
            <span className="font-extrabold text-xs sm:text-sm text-white truncate">
              {project.name}
            </span>
            <span className="text-[9px] uppercase font-bold px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 hidden sm:inline-block shrink-0">
              {project.category || 'Website'}
            </span>
          </div>
        </div>

        {/* RIGHT: SAVE & DOWNLOAD ZIP ACTIONS */}
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          <button
            onClick={onSaveProject}
            className="px-2.5 sm:px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs transition-colors flex items-center gap-1.5 border border-slate-700 cursor-pointer"
          >
            <Save className="w-3.5 h-3.5 text-indigo-400" />
            <span className="hidden sm:inline">Save</span>
          </button>

          <button
            onClick={onDownloadZip}
            className="px-3 sm:px-4 py-1.5 rounded-xl bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white font-bold text-xs shadow-md shadow-indigo-600/30 transition-all flex items-center gap-1.5 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden xs:inline">Download ZIP</span>
            <span className="xs:hidden">ZIP</span>
          </button>
        </div>
      </header>

      {/* THREE PANEL MAIN WORKSPACE (DESKTOP) */}
      <div className="flex-1 hidden md:grid md:grid-cols-12 overflow-hidden">
        {/* LEFT PANEL: FILE EXPLORER + CODE EDITOR (COL SPAN 4) */}
        <div className="col-span-4 grid grid-cols-12 border-r border-slate-800/80">
          <div className="col-span-4 border-r border-slate-800/80 bg-slate-950">
            <FileExplorer
              files={project.files}
              selectedFile={activeFile}
              onSelectFile={(f) => setActiveFile(f)}
              onAddFile={handleAddFile}
              onDeleteFile={handleDeleteFile}
            />
          </div>
          <div className="col-span-8 bg-slate-950">
            <CodeEditor
              files={project.files}
              activeFile={activeFile}
              onFileContentChange={handleFileContentChange}
              onSaveProject={onSaveProject}
              onToast={onToast}
            />
          </div>
        </div>

        {/* CENTER PANEL: LIVE PREVIEW (COL SPAN 5) */}
        <div className="col-span-5 bg-slate-950">
          <LivePreview files={project.files} />
        </div>

        {/* RIGHT PANEL: AI ASSISTANT (COL SPAN 3) */}
        <div className="col-span-3 bg-slate-950">
          <AIAssistant
            messages={messages}
            loading={loading}
            onSendPrompt={onSendAIPrompt}
            onRegenerate={onRegenerateAI}
            onUndo={onUndoAI}
            onAddProjectFile={handleAddFile}
          />
        </div>
      </div>

      {/* MOBILE RESPONSIVE TABBED VIEW */}
      <div className="flex-1 md:hidden overflow-hidden relative">
        {mobileTab === 'preview' && <LivePreview files={project.files} />}
        {mobileTab === 'code' && (
          <div className="h-full flex flex-col">
            <div className="h-36 border-b border-slate-800 bg-slate-950 overflow-y-auto">
              <FileExplorer
                files={project.files}
                selectedFile={activeFile}
                onSelectFile={(f) => setActiveFile(f)}
                onAddFile={handleAddFile}
                onDeleteFile={handleDeleteFile}
              />
            </div>
            <div className="flex-1 bg-slate-950">
              <CodeEditor
                files={project.files}
                activeFile={activeFile}
                onFileContentChange={handleFileContentChange}
                onSaveProject={onSaveProject}
                onToast={onToast}
              />
            </div>
          </div>
        )}
        {mobileTab === 'ai' && (
          <AIAssistant
            messages={messages}
            loading={loading}
            onSendPrompt={onSendAIPrompt}
            onRegenerate={onRegenerateAI}
            onUndo={onUndoAI}
            onAddProjectFile={handleAddFile}
          />
        )}
      </div>

      {/* MOBILE BOTTOM NAVIGATION TAB BAR */}
      <div className="md:hidden h-14 bg-slate-900 border-t border-slate-800 flex items-center justify-around text-slate-400 shrink-0">
        <button
          onClick={() => setMobileTab('preview')}
          className={`flex-1 py-2 flex flex-col items-center gap-1 text-[11px] font-semibold transition-colors cursor-pointer ${
            mobileTab === 'preview' ? 'text-indigo-400 bg-slate-800/40' : 'hover:text-slate-200'
          }`}
        >
          <Eye className="w-4 h-4" />
          <span>Preview</span>
        </button>
        <button
          onClick={() => setMobileTab('code')}
          className={`flex-1 py-2 flex flex-col items-center gap-1 text-[11px] font-semibold transition-colors cursor-pointer ${
            mobileTab === 'code' ? 'text-indigo-400 bg-slate-800/40' : 'hover:text-slate-200'
          }`}
        >
          <Code2 className="w-4 h-4" />
          <span>Code</span>
        </button>
        <button
          onClick={() => setMobileTab('ai')}
          className={`flex-1 py-2 flex flex-col items-center gap-1 text-[11px] font-semibold transition-colors cursor-pointer ${
            mobileTab === 'ai' ? 'text-indigo-400 bg-slate-800/40' : 'hover:text-slate-200'
          }`}
        >
          <Bot className="w-4 h-4" />
          <span>AI Chat</span>
        </button>
      </div>
    </div>
  );
};
