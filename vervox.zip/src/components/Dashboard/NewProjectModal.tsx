import React, { useState, useRef } from 'react';
import { Sparkles, Wand2, Layers, X, ArrowRight, Image as ImageIcon, Paperclip, FileText, Trash2 } from 'lucide-react';
import { ChatAttachment } from '../../types';

interface Props {
  isOpen: boolean;
  initialPrompt?: string;
  onClose: () => void;
  onGenerate: (prompt: string, attachments?: ChatAttachment[]) => void;
  onExploreTemplates: () => void;
}

export const NewProjectModal: React.FC<Props> = ({
  isOpen,
  initialPrompt = '',
  onClose,
  onGenerate,
  onExploreTemplates,
}) => {
  const [prompt, setPrompt] = useState(initialPrompt);
  const [attachments, setAttachments] = useState<ChatAttachment[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const suggestedPrompts = [
    'Portfolio Website',
    'Gaming Website',
    'Business Website',
    'Restaurant Website',
    'School Website',
    'Landing Page',
  ];

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const reader = new FileReader();
      reader.onload = (uploadEvent) => {
        const result = uploadEvent.target?.result as string;
        setAttachments((prev) => [
          ...prev,
          {
            name: file.name,
            type: 'image',
            dataUrl: result,
            size: file.size,
          },
        ]);
      };
      reader.readAsDataURL(file);
    }
    if (imageInputRef.current) imageInputRef.current.value = '';
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const text = await file.text();
      setAttachments((prev) => [
        ...prev,
        {
          name: file.name,
          type: 'file',
          textContent: text,
          size: file.size,
        },
      ]);
    }
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const removeAttachment = (index: number) => {
    setAttachments((prev) => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim() && attachments.length === 0) return;

    let finalPrompt = prompt.trim();
    if (attachments.length > 0) {
      const details = attachments
        .map((a) => (a.type === 'image' ? `[Custom Image/Photo: ${a.name}]` : `[Custom File Reference: ${a.name}]`))
        .join('\n');
      finalPrompt = finalPrompt ? `${finalPrompt}\n\nInclude assets:\n${details}` : `Build a website with attached assets:\n${details}`;
    }

    onGenerate(finalPrompt, attachments.length > 0 ? attachments : undefined);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in overflow-y-auto">
      <div className="relative w-full max-w-2xl rounded-2xl sm:rounded-3xl bg-slate-900 border border-slate-800 shadow-2xl p-5 sm:p-8 text-slate-100 my-auto">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2 text-indigo-400 text-xs font-mono font-bold uppercase tracking-wider mb-2">
          <Sparkles className="w-4 h-4" />
          VERVOX Website Generator
        </div>

        <h2 className="text-xl sm:text-2xl lg:text-3xl font-extrabold text-white mb-2">
          What do you want to build?
        </h2>
        <p className="text-slate-400 text-xs sm:text-sm mb-5 leading-relaxed">
          Describe your idea in plain English, attach reference photos or code files, and VERVOX AI will build your site.
        </p>

        <form onSubmit={handleSubmit} className="space-y-4 sm:space-y-5">
          <div className="relative">
            <textarea
              rows={4}
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Create a modern restaurant website with a beautiful hero section, menu cards, reservation section, testimonials and contact form."
              className="w-full bg-slate-950 border border-slate-800 rounded-2xl p-3.5 sm:p-4 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 leading-relaxed shadow-inner"
            />

            {/* ATTACHMENT ACTION BUTTONS INSIDE TEXTAREA */}
            <div className="absolute right-3 bottom-3 flex items-center gap-1.5 bg-slate-900/90 border border-slate-800 rounded-xl p-1 shadow-md">
              <button
                type="button"
                onClick={() => imageInputRef.current?.click()}
                className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-300 hover:bg-slate-800 transition-colors cursor-pointer"
                title="Attach photo/screenshot"
              >
                <ImageIcon className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-300 hover:bg-slate-800 transition-colors cursor-pointer"
                title="Attach file"
              >
                <Paperclip className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* HIDDEN FILE INPUTS */}
          <input
            type="file"
            ref={imageInputRef}
            onChange={handlePhotoUpload}
            accept="image/*"
            className="hidden"
            multiple
          />
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileUpload}
            accept=".html,.css,.js,.json,.txt,.md"
            className="hidden"
            multiple
          />

          {/* ATTACHED ASSETS PILLS */}
          {attachments.length > 0 && (
            <div className="space-y-1.5">
              <div className="text-[11px] font-semibold text-slate-400">Attached Media & Files:</div>
              <div className="flex flex-wrap gap-2">
                {attachments.map((att, idx) => (
                  <div
                    key={idx}
                    className="flex items-center gap-2 bg-slate-950 border border-indigo-500/40 rounded-xl p-1.5 pr-2.5 text-xs text-slate-200"
                  >
                    {att.type === 'image' && att.dataUrl ? (
                      <img src={att.dataUrl} alt={att.name} className="w-7 h-7 rounded-lg object-cover" />
                    ) : (
                      <FileText className="w-4 h-4 text-indigo-400 ml-1" />
                    )}
                    <span className="truncate max-w-[120px] font-mono text-[11px]">{att.name}</span>
                    <button
                      type="button"
                      onClick={() => removeAttachment(idx)}
                      className="p-0.5 rounded-full hover:bg-rose-500/20 text-slate-400 hover:text-rose-400 transition-colors cursor-pointer"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* SUGGESTED PROMPTS PILLS */}
          <div>
            <div className="text-xs font-semibold text-slate-400 mb-2">Suggested Ideas:</div>
            <div className="flex flex-wrap gap-1.5 sm:gap-2">
              {suggestedPrompts.map((sPrompt, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => setPrompt(`Create a modern ${sPrompt.toLowerCase()} with hero, feature cards, and contact section.`)}
                  className="text-[11px] sm:text-xs px-2.5 sm:px-3 py-1.5 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-white transition-colors cursor-pointer"
                >
                  + {sPrompt}
                </button>
              ))}
            </div>
          </div>

          {/* ACTION BUTTONS */}
          <div className="flex flex-col-reverse sm:flex-row items-center justify-end gap-2.5 sm:gap-3 pt-4 border-t border-slate-800">
            <button
              type="button"
              onClick={() => {
                onClose();
                onExploreTemplates();
              }}
              className="w-full sm:w-auto px-4 sm:px-5 py-3 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 font-semibold text-xs transition-colors flex items-center justify-center gap-2 cursor-pointer"
            >
              <Layers className="w-4 h-4 text-indigo-400" />
              Start From Template
            </button>

            <button
              type="submit"
              disabled={!prompt.trim() && attachments.length === 0}
              className="w-full sm:w-auto px-6 py-3 rounded-xl bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white font-bold text-xs shadow-lg shadow-indigo-600/30 transition-all hover:scale-[1.02] flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer"
            >
              <Wand2 className="w-4 h-4" />
              Generate Website
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
